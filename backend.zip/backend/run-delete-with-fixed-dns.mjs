﻿import dns from "node:dns";

dns.setServers(["8.8.8.8", "1.1.1.1"]);

console.log("Node DNS servers:", dns.getServers());

await import("./delete-duplicate-projects.mjs");
